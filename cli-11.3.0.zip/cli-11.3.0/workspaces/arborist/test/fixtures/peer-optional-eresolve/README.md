# peer optional failures

Cases which incorrectly caused `ERESOLVE` warnings.

[npm/arborist#223](https://github.com/npm/arborist/issues/223)
