# peer optional failure b

```
root -> (x) PEEROPTIONAL(y@1)
x -> PEEROPTIONAL(y@2)
```

[npm/arborist#223](https://github.com/npm/arborist/issues/223)
